#1> Set up node.js, npm

#2> cd to chat_app

#3> npm install

4#>open browser localhost:2000

> Start the chat