var express = require('express'),
	app = express(),
	server = require('http').createServer(app),
	io = require('socket.io').listen(server)

	server.listen(2000);

	console.log( 'server started' );

	app.get('/', function(req, res){
		res.sendFile(__dirname + '/index.html');
	})

	io.sockets.on('connection',function(socket){ // it is like $(document).ready(function()) in jquery, ie- socket codes goes inside this function
		socket.on('from_client', function(recieved_msg){	//  recieve a message from client side
			io.sockets.emit('from_server', recieved_msg) // broadcast message to every one including me
			// io.sockets.broadcast( 'return socket name', recieved_msg ) //  broadcast the message to every one excluding me
		})
	})